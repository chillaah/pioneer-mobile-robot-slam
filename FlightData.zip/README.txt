Flight Simulator Data Fields
----------------------------

Col 1: Ground Speed (kts)
Col 2: Altitude (feet)
COl 3: Heading (deg - from North)
Col 4: Latitude (deg)
Col 5: Longitude (deg)

Each row denotes a specific timestamp or epoch. 

The timestamps are montonically increasing as you move down the rows. 

The time interval between each timestamp is 0.4 seconds.